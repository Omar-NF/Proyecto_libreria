package com.example.proyectofinal


data class Comentario(
    val id: String,  // Identificador único del comentario
    val nombreUsuario: String,
    val mensaje: String
)