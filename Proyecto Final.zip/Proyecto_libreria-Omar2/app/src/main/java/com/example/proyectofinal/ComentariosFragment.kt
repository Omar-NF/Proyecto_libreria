package com.example.proyectofinal.ui.comentarios

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.proyectofinal.Comentario
import com.example.proyectofinal.ComentarioAdapter
import com.example.proyectofinal.databinding.FragmentComentariosBinding

class ComentariosFragment : Fragment() {

    private var _binding: FragmentComentariosBinding? = null
    private val binding get() = _binding!!

    private val comentariosList = mutableListOf<Comentario>()
    private lateinit var comentariosAdapter: ComentarioAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentComentariosBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        comentariosAdapter = ComentarioAdapter(comentariosList)
        binding.recyclerViewComentarios.apply {
            adapter = comentariosAdapter
            layoutManager = LinearLayoutManager(requireContext())
        }

        binding.btnAgregarComentario.setOnClickListener {
            val nuevoComentario = binding.editTextComentario.text.toString()
            if (nuevoComentario.isNotBlank()) {
                val comentario = Comentario(
                    id = comentariosList.size.toString(),
                    nombreUsuario = "Usuario",  // Aquí deberías obtener el nombre de usuario del usuario actual
                    mensaje = nuevoComentario
                )
                comentariosList.add(comentario)
                comentariosAdapter.notifyDataSetChanged()
                binding.editTextComentario.text.clear()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}