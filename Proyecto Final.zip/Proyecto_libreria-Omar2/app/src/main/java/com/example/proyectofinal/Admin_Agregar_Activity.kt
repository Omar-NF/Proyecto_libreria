package com.example.proyectofinal

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

class Admin_Agregar_Activity : AppCompatActivity() {
    private lateinit var nombreLibros: EditText
    private lateinit var generoLibros: Spinner
    private lateinit var precioLibros: EditText
    private lateinit var descripcionLibros: EditText
    private lateinit var grupo: RadioGroup
    private lateinit var renta: RadioButton
    private lateinit var venta: RadioButton
    private lateinit var ambos: RadioButton
    private lateinit var guardar: Button
    private lateinit var borrar: Button
    private var opcionSel = "1"
    private val sharedPrefsFile = "LibraryPrefs"
    private val gson = Gson()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_agregar)

        nombreLibros = findViewById(R.id.edtNombre)
        generoLibros = findViewById(R.id.spSpinner)
        precioLibros = findViewById(R.id.edtPrecio)
        descripcionLibros = findViewById(R.id.edtDescripcion)
        grupo = findViewById(R.id.rdGrupo)
        renta = findViewById(R.id.rdRenta)
        venta = findViewById(R.id.rdVenta)
        ambos = findViewById(R.id.rdAmbos)
        guardar = findViewById(R.id.btnGuardarLib)
        borrar = findViewById(R.id.btnBorrarLib)

        val adaptador = ArrayAdapter.createFromResource(this, R.array.stArrayGeneros, android.R.layout.simple_spinner_item)
        adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        generoLibros.adapter = adaptador

        generoLibros.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                opcionSel = generoLibros.selectedItem.toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
            }
        }

        guardar.setOnClickListener {
            guardarLibro()
        }

        borrar.setOnClickListener {
            regresarAdmin()
        }
    }

    fun guardarLibro() {
        val nombre = nombreLibros.text.toString()
        val genero = opcionSel
        val precio = precioLibros.text.toString().toIntOrNull() ?: 0
        val descripcion = descripcionLibros.text.toString()
        val disponibilidad = when (grupo.checkedRadioButtonId) {
            R.id.rdRenta -> "Renta"
            R.id.rdVenta -> "Venta"
            R.id.rdAmbos -> "Ambos"
            else -> ""
        }

        if (nombre.isEmpty() || genero.isEmpty() || precio <= 0 || descripcion.isEmpty() || disponibilidad.isEmpty()) {
            Toast.makeText(this, "Todos los campos son obligatorios.", Toast.LENGTH_SHORT).show()
            return
        }

        val id = UUID.randomUUID().toString()
        val libro = Libro(id, nombre, genero, precio, descripcion, disponibilidad)

        val sharedPreferences = getSharedPreferences(sharedPrefsFile, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val librosJson = sharedPreferences.getString("libros", null)
        val librosListType = object : TypeToken<MutableList<Libro>>() {}.type
        val librosList: MutableList<Libro> = if (librosJson.isNullOrEmpty()) {
            mutableListOf()
        } else {
            gson.fromJson(librosJson, librosListType)
        }

        librosList.add(libro)
        val updatedLibrosJson = gson.toJson(librosList)
        editor.putString("libros", updatedLibrosJson)
        editor.apply()

        Toast.makeText(this, "Libro guardado exitosamente.", Toast.LENGTH_SHORT).show()
        regresarAdmin()
    }

    fun regresarAdmin() {
        val intent = Intent(this, AdminActivity::class.java)
        startActivity(intent)
        finish()
    }
}